// Simple smoke tests using Node's built-in test runner (no extra dependencies).
// Run with: npm test
//
// These tests spin up the Express app in-memory (via supertest-like manual
// requests using Node's http module) against a dedicated test database file
// so they never touch your real data.

const test = require("node:test");
const assert = require("node:assert/strict");
const path = require("node:path");
const fs = require("node:fs");
const http = require("node:http");

process.env.NODE_ENV = "test";
process.env.DB_PATH = path.join(__dirname, "test.db");

// Start from a clean database file every test run.
for (const suffix of ["", "-journal", "-wal", "-shm"]) {
  const file = process.env.DB_PATH + suffix;
  if (fs.existsSync(file)) fs.rmSync(file);
}

const app = require("../src/app");
const db = require("../src/config/db");

let server;
let baseUrl;

test.before(() => {
  server = http.createServer(app).listen(0);
  const { port } = server.address();
  baseUrl = `http://127.0.0.1:${port}`;
});

test.after(() => {
  server.close();
  db.close();
  for (const suffix of ["", "-journal", "-wal", "-shm"]) {
    const file = process.env.DB_PATH + suffix;
    if (fs.existsSync(file)) fs.rmSync(file);
  }
});

async function request(method, urlPath, body) {
  const res = await fetch(`${baseUrl}${urlPath}`, {
    method,
    headers: body ? { "Content-Type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => null);
  return { status: res.status, body: json };
}

test("GET /api/health returns ok", async () => {
  const res = await request("GET", "/api/health");
  assert.equal(res.status, 200);
  assert.equal(res.body.success, true);
});

test("GET /api/v1/internships returns empty paginated list initially", async () => {
  const res = await request("GET", "/api/v1/internships");
  assert.equal(res.status, 200);
  assert.equal(res.body.success, true);
  assert.deepEqual(res.body.data, []);
  assert.equal(res.body.meta.totalItems, 0);
});

let createdId;

test("POST /api/v1/internships creates a new internship", async () => {
  const res = await request("POST", "/api/v1/internships", {
    title: "Test Intern Role",
    company: "Fictional Co",
    location: "Remote",
    category: "Software Development",
    type: "Remote",
    duration_months: 3,
    stipend: 1000,
    is_open: true,
  });
  assert.equal(res.status, 201);
  assert.equal(res.body.success, true);
  assert.ok(res.body.data.id);
  createdId = res.body.data.id;
});

test("POST /api/v1/internships rejects invalid payloads", async () => {
  const res = await request("POST", "/api/v1/internships", { title: "Hi" });
  assert.equal(res.status, 400);
  assert.equal(res.body.success, false);
  assert.ok(Array.isArray(res.body.error.details));
});

test("GET /api/v1/internships/:id returns the created record", async () => {
  const res = await request("GET", `/api/v1/internships/${createdId}`);
  assert.equal(res.status, 200);
  assert.equal(res.body.data.title, "Test Intern Role");
});

test("GET /api/v1/internships/:id returns 404 for unknown id", async () => {
  const res = await request("GET", "/api/v1/internships/999999");
  assert.equal(res.status, 404);
  assert.equal(res.body.success, false);
});

test("PATCH /api/v1/internships/:id partially updates the record", async () => {
  const res = await request("PATCH", `/api/v1/internships/${createdId}`, { is_open: false });
  assert.equal(res.status, 200);
  assert.equal(res.body.data.is_open, false);
});

test("PUT /api/v1/internships/:id replaces the record", async () => {
  const res = await request("PUT", `/api/v1/internships/${createdId}`, {
    title: "Updated Intern Role",
    company: "Fictional Co",
    location: "Remote",
    category: "Software Development",
    type: "Onsite",
    duration_months: 4,
    stipend: 1200,
    is_open: true,
  });
  assert.equal(res.status, 200);
  assert.equal(res.body.data.title, "Updated Intern Role");
  assert.equal(res.body.data.type, "Onsite");
});

test("DELETE /api/v1/internships/:id removes the record", async () => {
  const res = await request("DELETE", `/api/v1/internships/${createdId}`);
  assert.equal(res.status, 200);
  assert.equal(res.body.success, true);

  const followUp = await request("GET", `/api/v1/internships/${createdId}`);
  assert.equal(followUp.status, 404);
});
