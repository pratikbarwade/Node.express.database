# API Examples

Base URL (local development): `http://localhost:4000`

All responses are JSON and follow one of these two envelopes:

```json
{ "success": true, "data": {}, "meta": {} }
```

```json
{ "success": false, "error": { "message": "...", "details": [] } }
```

> Tip: import [`postman_collection.json`](./postman_collection.json) into Postman/Insomnia to run every example below with one click.

---

## 1. Health check

```bash
curl http://localhost:4000/api/health
```

```json
{ "success": true, "status": "ok", "uptime": 12.4 }
```

---

## 2. List internships (pagination + filtering)

```bash
curl "http://localhost:4000/api/v1/internships?page=1&limit=5"
```

```json
{
  "success": true,
  "data": [
    { "id": 1, "title": "Frontend Engineering Intern", "company": "NimbusTech", "...": "..." }
  ],
  "meta": {
    "currentPage": 1,
    "pageSize": 5,
    "totalItems": 15,
    "totalPages": 3,
    "hasNextPage": true,
    "hasPrevPage": false
  }
}
```

### Filtering & searching

| Query param | Example                        | Description                                   |
| ----------- | ------------------------------- | ---------------------------------------------- |
| `page`      | `?page=2`                       | Page number (default `1`)                      |
| `limit`     | `?limit=5`                      | Items per page, max `50` (default `10`)        |
| `category`  | `?category=Data%20Science`      | Exact match, case-insensitive                  |
| `type`      | `?type=Remote`                  | One of `Remote`, `Onsite`, `Hybrid`            |
| `location`  | `?location=Austin`              | Partial, case-insensitive match                |
| `isOpen`    | `?isOpen=true`                  | Filter by open/closed positions                |
| `search`    | `?search=engineer`              | Matches against `title` or `company`           |
| `sortBy`    | `?sortBy=stipend`                | `id`, `title`, `company`, `stipend`, `duration_months`, `posted_date`, `application_deadline`, `created_at` |
| `order`     | `?order=desc`                   | `asc` (default) or `desc`                      |

```bash
curl "http://localhost:4000/api/v1/internships?category=Software%20Development&isOpen=true&sortBy=stipend&order=desc"
```

---

## 3. Get a single internship

```bash
curl http://localhost:4000/api/v1/internships/1
```

```json
{
  "success": true,
  "data": {
    "id": 1,
    "title": "Frontend Engineering Intern",
    "company": "NimbusTech",
    "location": "Austin, TX",
    "category": "Software Development",
    "type": "Remote",
    "duration_months": 3,
    "stipend": 1800,
    "is_open": true,
    "description": "Work with the web platform team building React components for the Nimbus dashboard.",
    "application_deadline": "2026-02-15",
    "posted_date": "2026-01-05",
    "created_at": "2026-01-05 10:00:00",
    "updated_at": "2026-01-05 10:00:00"
  }
}
```

Requesting an id that doesn't exist returns `404`:

```bash
curl -i http://localhost:4000/api/v1/internships/9999
```

```json
{ "success": false, "error": { "message": "Internship with id 9999 was not found" } }
```

---

## 4. Create an internship

```bash
curl -X POST http://localhost:4000/api/v1/internships \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Cloud Infrastructure Intern",
    "company": "Cobalt Security",
    "location": "Seattle, WA",
    "category": "Software Development",
    "type": "Hybrid",
    "duration_months": 5,
    "stipend": 2100,
    "is_open": true,
    "description": "Support the DevOps team with monitoring and fictional incident response drills.",
    "application_deadline": "2026-04-01"
  }'
```

`201 Created`:

```json
{
  "success": true,
  "data": {
    "id": 16,
    "title": "Cloud Infrastructure Intern",
    "company": "Cobalt Security",
    "...": "..."
  }
}
```

### Validation error example

```bash
curl -i -X POST http://localhost:4000/api/v1/internships \
  -H "Content-Type: application/json" \
  -d '{ "title": "Hi", "type": "Onsitee" }'
```

`400 Bad Request`:

```json
{
  "success": false,
  "error": {
    "message": "Validation failed",
    "details": [
      { "field": "title", "message": "Invalid value" },
      { "field": "company", "message": "company is required" },
      { "field": "location", "message": "location is required" },
      { "field": "category", "message": "category is required" },
      { "field": "type", "message": "type must be one of: Remote, Onsite, Hybrid" },
      { "field": "duration_months", "message": "duration_months is required" },
      { "field": "stipend", "message": "stipend is required" }
    ]
  }
}
```

---

## 5. Replace an internship (PUT — all fields required)

```bash
curl -X PUT http://localhost:4000/api/v1/internships/16 \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Cloud Infrastructure Intern II",
    "company": "Cobalt Security",
    "location": "Seattle, WA",
    "category": "Software Development",
    "type": "Onsite",
    "duration_months": 6,
    "stipend": 2300,
    "is_open": true,
    "description": "Updated scope: now includes on-call shadowing.",
    "application_deadline": "2026-04-10"
  }'
```

---

## 6. Partially update an internship (PATCH)

```bash
curl -X PATCH http://localhost:4000/api/v1/internships/16 \
  -H "Content-Type: application/json" \
  -d '{ "is_open": false }'
```

```json
{ "success": true, "data": { "id": 16, "is_open": false, "...": "..." } }
```

---

## 7. Delete an internship

```bash
curl -X DELETE http://localhost:4000/api/v1/internships/16
```

```json
{
  "success": true,
  "message": "Internship with id 16 was deleted",
  "data": { "id": 16, "title": "Cloud Infrastructure Intern II", "...": "..." }
}
```

---

## Status code summary

| Code | Meaning                                            |
| ---- | --------------------------------------------------- |
| 200  | Successful GET / PUT / PATCH / DELETE                |
| 201  | Resource created (POST)                              |
| 400  | Validation error / malformed request                 |
| 404  | Resource or route not found                          |
| 500  | Unexpected server error                              |
