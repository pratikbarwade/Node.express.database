-- Ready-to-import sample database for the Internship Records API
-- SQLite-compatible schema + fictional seed records.
--
-- Usage:
--   sqlite3 data/internship.db < docs/sample-database.sql
--
-- This file is equivalent to running `npm run seed:fresh`, but lets you
-- import the schema + data directly with the sqlite3 CLI if you prefer.

PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS internships;

CREATE TABLE internships (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  title                 TEXT    NOT NULL,
  company               TEXT    NOT NULL,
  location              TEXT    NOT NULL,
  category              TEXT    NOT NULL,
  type                  TEXT    NOT NULL CHECK (type IN ('Remote', 'Onsite', 'Hybrid')),
  duration_months       INTEGER NOT NULL CHECK (duration_months BETWEEN 1 AND 24),
  stipend               INTEGER NOT NULL DEFAULT 0 CHECK (stipend >= 0),
  is_open               INTEGER NOT NULL DEFAULT 1 CHECK (is_open IN (0, 1)),
  description           TEXT,
  application_deadline  TEXT,
  posted_date           TEXT    NOT NULL DEFAULT (date('now')),
  created_at            TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at            TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX idx_internships_category ON internships (category);
CREATE INDEX idx_internships_type     ON internships (type);
CREATE INDEX idx_internships_is_open  ON internships (is_open);
CREATE INDEX idx_internships_location ON internships (location);

INSERT INTO internships
  (title, company, location, category, type, duration_months, stipend, is_open, description, application_deadline, posted_date)
VALUES
  ('Frontend Engineering Intern', 'NimbusTech', 'Austin, TX', 'Software Development', 'Remote', 3, 1800, 1, 'Work with the web platform team building React components for the Nimbus dashboard.', '2026-02-15', '2026-01-05'),
  ('Backend Engineering Intern', 'NimbusTech', 'Austin, TX', 'Software Development', 'Hybrid', 6, 2200, 1, 'Build and maintain REST APIs for the Nimbus billing service using Node.js.', '2026-02-20', '2026-01-06'),
  ('Data Science Intern', 'Solstice Analytics', 'Chicago, IL', 'Data Science', 'Onsite', 4, 2000, 1, 'Assist in building churn-prediction models and cleaning large fictional customer datasets.', '2026-03-01', '2026-01-08'),
  ('Machine Learning Research Intern', 'Solstice Analytics', 'Chicago, IL', 'Data Science', 'Hybrid', 6, 2500, 0, 'Research recommendation algorithms alongside the applied ML team. Cohort is currently full.', '2026-01-10', '2025-11-20'),
  ('Digital Marketing Intern', 'BrightPath Media', 'Remote', 'Marketing', 'Remote', 3, 1200, 1, 'Support social media campaigns and analyze engagement metrics for fictional client brands.', '2026-02-10', '2026-01-02'),
  ('Content Writing Intern', 'BrightPath Media', 'Remote', 'Content Writing', 'Remote', 2, 900, 1, 'Write blog posts, newsletters, and landing page copy for the BrightPath content studio.', '2026-02-05', '2026-01-03'),
  ('Financial Analyst Intern', 'Quantum Finance Group', 'New York, NY', 'Finance', 'Onsite', 6, 2800, 1, 'Support quarterly forecasting and build financial models for the corporate strategy team.', '2026-03-15', '2026-01-10'),
  ('Human Resources Intern', 'Cascade Health Systems', 'Denver, CO', 'Human Resources', 'Onsite', 3, 1100, 1, 'Assist the talent acquisition team with scheduling, onboarding, and candidate communication.', '2026-02-25', '2026-01-04'),
  ('UI/UX Design Intern', 'PixelForge Studios', 'Remote', 'Design', 'Remote', 4, 1600, 1, 'Design wireframes and prototypes for indie game studio clients using Figma.', '2026-02-18', '2026-01-07'),
  ('Mechanical Engineering Intern', 'Vertex Robotics', 'Pittsburgh, PA', 'Mechanical Engineering', 'Onsite', 6, 2400, 1, 'Prototype and test actuator assemblies for next-generation warehouse robots.', '2026-03-05', '2026-01-09'),
  ('Business Development Intern', 'Orbit Logistics', 'Miami, FL', 'Business Development', 'Hybrid', 3, 1400, 0, 'Research new shipping partnerships and support the sales pipeline. Position now filled.', '2026-01-05', '2025-11-15'),
  ('Customer Support Intern', 'Orbit Logistics', 'Miami, FL', 'Customer Support', 'Remote', 2, 900, 1, 'Handle tier-1 support tickets and help maintain the internal knowledge base.', '2026-02-12', '2026-01-11'),
  ('Legal Research Intern', 'Meridian Legal Partners', 'Boston, MA', 'Legal', 'Onsite', 4, 1900, 1, 'Assist associates with case research, document review, and citation checking.', '2026-03-10', '2026-01-12'),
  ('Biotech Research Intern', 'Aurora BioLabs', 'San Diego, CA', 'Research', 'Onsite', 6, 2600, 1, 'Support wet-lab experiments and data logging for a fictional gene-therapy research program.', '2026-03-20', '2026-01-13'),
  ('Operations Intern', 'GreenLeaf Foods', 'Portland, OR', 'Operations', 'Hybrid', 3, 1300, 1, 'Help streamline warehouse inventory processes and vendor coordination.', '2026-02-22', '2026-01-06');
