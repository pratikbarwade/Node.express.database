# Internship Records API

A beginner-friendly REST API for managing **internship records**, built with
**Node.js**, **Express.js**, and **SQLite**. It supports full CRUD operations,
request validation, pagination, filtering/sorting, consistent error handling,
seed data, and automated tests — everything you need for a GitHub-ready
submission.

> All data in this project (companies, internships, people) is **fictional**
> and used only for demonstration/testing purposes.

---

## Table of contents

1. [Objective](#objective)
2. [Tech stack](#tech-stack)
3. [Features](#features)
4. [Project structure](#project-structure)
5. [Data model](#data-model)
6. [Getting started](#getting-started)
7. [Environment variables](#environment-variables)
8. [Seed data](#seed-data)
9. [API reference](#api-reference)
10. [Response & error format](#response--error-format)
11. [Validation rules](#validation-rules)
12. [Pagination, filtering & sorting](#pagination-filtering--sorting)
13. [Running tests](#running-tests)
14. [API examples](#api-examples)
15. [Troubleshooting](#troubleshooting)
16. [License](#license)

---

## Objective

Design predictable API contracts and safe **create, read, update, and
delete** operations for an internship-listing board, so that a frontend (or
another service) can rely on consistent status codes, response shapes, and
validation errors.

## Tech stack

- **Runtime:** Node.js (v18+)
- **Framework:** Express.js
- **Database:** SQLite (via [`better-sqlite3`](https://github.com/WiseLibs/better-sqlite3), synchronous & beginner-friendly)
- **Validation:** [`express-validator`](https://express-validator.github.io/)
- **Other:** `cors`, `morgan` (logging), `dotenv` (config)
- **Testing:** Node.js built-in test runner (`node --test`) — no extra frameworks required

## Features

- ✅ Full CRUD for internship records (`GET`, `POST`, `PUT`, `PATCH`, `DELETE`)
- ✅ Request body & query parameter validation with clear, field-level error messages
- ✅ Pagination (`page`, `limit`) with rich metadata
- ✅ Filtering by `category`, `type`, `location`, `isOpen`, and free-text `search`
- ✅ Sorting by any safe column (`sortBy`, `order`)
- ✅ Consistent JSON response envelope for success and error cases
- ✅ Centralized error handling + 404 handler
- ✅ Auto-created schema on boot (no manual migration step)
- ✅ Idempotent seed script with 15 fictional internship records
- ✅ Ready-to-import `.sql` dump and `.json` seed records for grading/testing
- ✅ Automated smoke tests covering every endpoint
- ✅ Postman collection + curl examples

## Project structure

```
internship-api/
├── data/                       # SQLite database file lives here (gitignored)
├── docs/
│   ├── API_EXAMPLES.md         # curl examples for every endpoint
│   ├── postman_collection.json # Importable Postman collection
│   ├── sample-database.sql     # Ready-to-import schema + seed data
│   └── seed-records.json       # Stable fictional seed records (JSON)
├── src/
│   ├── app.js                  # Express app setup (middleware + routes)
│   ├── config/
│   │   └── db.js               # SQLite connection + schema bootstrap
│   ├── controllers/
│   │   └── internshipController.js
│   ├── db/
│   │   ├── schema.sql           # Table definition
│   │   ├── seed.js              # Seed script (npm run seed)
│   │   └── seed-data.json       # Source of truth for seed data
│   ├── middleware/
│   │   ├── errorHandler.js      # 404 + centralized error handler
│   │   └── validateRequest.js   # express-validator result handler
│   ├── models/
│   │   └── internshipModel.js   # All SQL queries live here
│   ├── routes/
│   │   └── internshipRoutes.js
│   ├── utils/
│   │   ├── ApiError.js
│   │   ├── asyncHandler.js
│   │   └── pagination.js
├── tests/
│   └── internships.test.js      # Automated smoke tests
├── .env.example
├── .gitignore
├── LICENSE
├── package.json
└── server.js                    # Entry point
```

## Data model

Table: **`internships`**

| Column                 | Type    | Notes                                             |
| ----------------------- | ------- | -------------------------------------------------- |
| `id`                    | INTEGER | Primary key, auto-increment                        |
| `title`                 | TEXT    | Required, 3–150 chars                              |
| `company`               | TEXT    | Required, 2–120 chars                              |
| `location`              | TEXT    | Required, 2–120 chars                              |
| `category`              | TEXT    | Required, e.g. "Software Development"              |
| `type`                  | TEXT    | Required. One of `Remote`, `Onsite`, `Hybrid`      |
| `duration_months`       | INTEGER | Required, 1–24                                     |
| `stipend`               | INTEGER | Required, >= 0 (monthly stipend in USD)            |
| `is_open`               | BOOLEAN | Defaults to `true`                                 |
| `description`           | TEXT    | Optional, up to 2000 chars                         |
| `application_deadline`  | TEXT    | Optional, ISO date `YYYY-MM-DD`                    |
| `posted_date`           | TEXT    | Auto-set to today if omitted on create             |
| `created_at`             | TEXT    | Auto-managed timestamp                             |
| `updated_at`             | TEXT    | Auto-managed timestamp                             |

See [`src/db/schema.sql`](./src/db/schema.sql) for the full SQL definition.

## Getting started

```bash
# 1. Clone the repository, then move into this folder
cd internship-api

# 2. Install dependencies
npm install

# 3. Copy environment variables
cp .env.example .env

# 4. Seed the SQLite database with fictional sample data
npm run seed

# 5. Start the server (with auto-reload)
npm run dev

# ...or start it normally
npm start
```

The API will be available at **http://localhost:4000**.

Verify it's running:

```bash
curl http://localhost:4000/api/health
# { "success": true, "status": "ok", "uptime": 1.23 }
```

> The database schema is created automatically the first time the app
> connects to SQLite — you don't need a separate migration step.

## Environment variables

Defined in `.env` (copy from `.env.example`):

| Variable    | Default                    | Description                              |
| ----------- | --------------------------- | ------------------------------------------ |
| `PORT`      | `4000`                      | Port the Express server listens on        |
| `DB_PATH`   | `./data/internship.db`      | Path to the SQLite database file          |
| `NODE_ENV`  | `development`               | `development`, `production`, or `test`    |

## Seed data

Fictional data lives in [`src/db/seed-data.json`](./src/db/seed-data.json)
(15 internships across categories like Software Development, Data Science,
Marketing, Finance, Design, and more).

```bash
npm run seed         # inserts seed data only if the table is empty
npm run seed:fresh   # wipes the table and reseeds from scratch
```

Prefer plain SQL? Import the ready-to-use dump directly:

```bash
sqlite3 data/internship.db < docs/sample-database.sql
```

A stable, ID-annotated copy of the same records is also available at
[`docs/seed-records.json`](./docs/seed-records.json) for grading/testing.

## API reference

Base URL: `http://localhost:4000`

| Method   | Endpoint                     | Description                          |
| -------- | ----------------------------- | ------------------------------------- |
| `GET`    | `/api/health`                 | Health check                          |
| `GET`    | `/api/v1/internships`         | List internships (paginated, filterable) |
| `GET`    | `/api/v1/internships/:id`     | Get a single internship by id         |
| `POST`   | `/api/v1/internships`         | Create a new internship               |
| `PUT`    | `/api/v1/internships/:id`     | Replace an internship (all fields required) |
| `PATCH`  | `/api/v1/internships/:id`     | Partially update an internship        |
| `DELETE` | `/api/v1/internships/:id`     | Delete an internship                  |

Full request/response examples: [`docs/API_EXAMPLES.md`](./docs/API_EXAMPLES.md)

## Response & error format

**Success:**

```json
{ "success": true, "data": { }, "meta": { } }
```

**Error:**

```json
{ "success": false, "error": { "message": "...", "details": [ ] } }
```

| Status | When it happens                                     |
| ------ | ---------------------------------------------------- |
| 200    | Successful GET / PUT / PATCH / DELETE                |
| 201    | Resource successfully created (POST)                 |
| 400    | Validation error or malformed request body           |
| 404    | Resource or route not found                          |
| 500    | Unexpected server error                              |

## Validation rules

Enforced with `express-validator` (see
[`src/validators/internshipValidators.js`](./src/validators/internshipValidators.js)):

- `title` — required, string, 3–150 characters
- `company` — required, string, 2–120 characters
- `location` — required, string, 2–120 characters
- `category` — required, string, 2–80 characters
- `type` — required, must be `Remote`, `Onsite`, or `Hybrid`
- `duration_months` — required, integer between 1 and 24
- `stipend` — required, integer >= 0
- `is_open` — optional boolean (defaults to `true`)
- `description` — optional string, up to 2000 characters
- `application_deadline` — optional, ISO date (`YYYY-MM-DD`)

`POST` and `PUT` require every field above (except the optional ones).
`PATCH` accepts any subset of fields, but the request body must not be empty.

Invalid requests return `400` with a `details` array describing every failed
field, e.g.:

```json
{
  "success": false,
  "error": {
    "message": "Validation failed",
    "details": [{ "field": "stipend", "message": "stipend must be a non-negative integer" }]
  }
}
```

## Pagination, filtering & sorting

`GET /api/v1/internships` supports:

| Param      | Example                    | Notes                                   |
| ---------- | ---------------------------- | ----------------------------------------- |
| `page`     | `?page=2`                   | Default `1`                               |
| `limit`    | `?limit=5`                  | Default `10`, max `50`                    |
| `category` | `?category=Marketing`       | Exact match, case-insensitive             |
| `type`     | `?type=Remote`              | `Remote` \| `Onsite` \| `Hybrid`          |
| `location` | `?location=Austin`          | Partial match, case-insensitive           |
| `isOpen`   | `?isOpen=true`               | `true`/`false`                            |
| `search`   | `?search=engineer`          | Matches `title` or `company`              |
| `sortBy`   | `?sortBy=stipend`            | `id`, `title`, `company`, `stipend`, `duration_months`, `posted_date`, `application_deadline`, `created_at` |
| `order`    | `?order=desc`                | `asc` (default) or `desc`                 |

List responses include a `meta` object:

```json
{
  "currentPage": 1,
  "pageSize": 10,
  "totalItems": 15,
  "totalPages": 2,
  "hasNextPage": true,
  "hasPrevPage": false
}
```

## Running tests

```bash
npm test
```

This runs an isolated smoke-test suite (Node's built-in test runner) against
a temporary SQLite database (`tests/test.db`, auto-created and cleaned up),
covering every CRUD endpoint, validation errors, and 404 handling.

## API examples

See [`docs/API_EXAMPLES.md`](./docs/API_EXAMPLES.md) for curl examples of
every endpoint, or import [`docs/postman_collection.json`](./docs/postman_collection.json)
into Postman/Insomnia.

## Troubleshooting

- **`SQLITE_CANTOPEN` or missing folder:** `src/config/db.js` auto-creates
  the `data/` folder, but make sure the process has write permissions.
- **Port already in use:** change `PORT` in `.env`.
- **Want to start fresh?** Delete everything in `data/` and re-run `npm run seed`.
- **Native build issues with `better-sqlite3`:** make sure you're on Node.js
  18+ and re-run `npm install` (prebuilt binaries are used automatically on
  most platforms).

## License

[MIT](./LICENSE) — free to use for learning, portfolios, and interviews.
