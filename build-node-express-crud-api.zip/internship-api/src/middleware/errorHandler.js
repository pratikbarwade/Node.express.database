const ApiError = require("../utils/ApiError");

// 404 handler for any route that doesn't match.
function notFound(req, res, _next) {
  res.status(404).json({
    success: false,
    error: {
      message: `Route not found: ${req.method} ${req.originalUrl}`,
    },
  });
}

// Centralized error handler. Any `next(err)` call ends up here.
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (err instanceof ApiError) {
    return res.status(err.statusCode).json({
      success: false,
      error: {
        message: err.message,
        ...(err.details ? { details: err.details } : {}),
      },
    });
  }

  // SQLite constraint errors (e.g. CHECK failures) are surfaced as 400s.
  if (err && err.code && String(err.code).startsWith("SQLITE_CONSTRAINT")) {
    return res.status(400).json({
      success: false,
      error: { message: "Database constraint violation", details: err.message },
    });
  }

  console.error(err);

  res.status(500).json({
    success: false,
    error: { message: "Internal server error" },
  });
}

module.exports = { notFound, errorHandler };
