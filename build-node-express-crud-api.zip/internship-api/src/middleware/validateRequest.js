const { validationResult } = require("express-validator");

// Runs after express-validator's chain of validators. If any of them
// failed, respond with a consistent 400 error payload.
function validateRequest(req, res, next) {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      error: {
        message: "Validation failed",
        details: errors.array().map((err) => ({
          field: err.path,
          message: err.msg,
        })),
      },
    });
  }

  next();
}

module.exports = validateRequest;
