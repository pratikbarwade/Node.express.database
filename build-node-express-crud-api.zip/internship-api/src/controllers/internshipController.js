const internshipModel = require("../models/internshipModel");
const asyncHandler = require("../utils/asyncHandler");
const ApiError = require("../utils/ApiError");
const { parsePagination, buildMeta } = require("../utils/pagination");

// GET /api/v1/internships
const getInternships = asyncHandler(async (req, res) => {
  const { page, limit, offset } = parsePagination(req.query);
  const { category, type, location, isOpen, search, sortBy, order } = req.query;

  const { rows, totalItems } = internshipModel.findAll({
    limit,
    offset,
    category,
    type,
    location,
    isOpen,
    search,
    sortBy,
    order,
  });

  res.status(200).json({
    success: true,
    data: rows.map(serializeInternship),
    meta: buildMeta({ page, limit, totalItems }),
  });
});

// GET /api/v1/internships/:id
const getInternshipById = asyncHandler(async (req, res) => {
  const internship = internshipModel.findById(Number(req.params.id));

  if (!internship) {
    throw new ApiError(404, `Internship with id ${req.params.id} was not found`);
  }

  res.status(200).json({ success: true, data: serializeInternship(internship) });
});

// POST /api/v1/internships
const createInternship = asyncHandler(async (req, res) => {
  const payload = pickInternshipFields(req.body);
  const created = internshipModel.create(payload);

  res.status(201).json({ success: true, data: serializeInternship(created) });
});

// PUT /api/v1/internships/:id  (full replace — all fields required)
const updateInternship = asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const existing = internshipModel.findById(id);

  if (!existing) {
    throw new ApiError(404, `Internship with id ${id} was not found`);
  }

  const payload = pickInternshipFields(req.body, { withDefaults: true });
  const updated = internshipModel.replace(id, payload);

  res.status(200).json({ success: true, data: serializeInternship(updated) });
});

// PATCH /api/v1/internships/:id (partial update)
const patchInternship = asyncHandler(async (req, res) => {
  const id = Number(req.params.id);

  if (Object.keys(req.body || {}).length === 0) {
    throw new ApiError(400, "Request body must include at least one field to update");
  }

  const payload = pickInternshipFields(req.body, { partial: true });
  const updated = internshipModel.patch(id, payload);

  if (!updated) {
    throw new ApiError(404, `Internship with id ${id} was not found`);
  }

  res.status(200).json({ success: true, data: serializeInternship(updated) });
});

// DELETE /api/v1/internships/:id
const deleteInternship = asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const removed = internshipModel.remove(id);

  if (!removed) {
    throw new ApiError(404, `Internship with id ${id} was not found`);
  }

  res.status(200).json({
    success: true,
    message: `Internship with id ${id} was deleted`,
    data: serializeInternship(removed),
  });
});

// --- helpers -----------------------------------------------------------

function pickInternshipFields(body, { partial = false, withDefaults = false } = {}) {
  const fields = [
    "title",
    "company",
    "location",
    "category",
    "type",
    "duration_months",
    "stipend",
    "is_open",
    "description",
    "application_deadline",
  ];

  const result = {};

  for (const field of fields) {
    if (body[field] !== undefined) {
      result[field] = field === "is_open" ? (body[field] ? 1 : 0) : body[field];
    }
  }

  if (!partial && withDefaults && result.is_open === undefined) {
    result.is_open = 1;
  }
  if (!partial && result.is_open === undefined) {
    result.is_open = 1;
  }

  return result;
}

function serializeInternship(row) {
  if (!row) return row;
  return {
    ...row,
    is_open: Boolean(row.is_open),
  };
}

module.exports = {
  getInternships,
  getInternshipById,
  createInternship,
  updateInternship,
  patchInternship,
  deleteInternship,
};
