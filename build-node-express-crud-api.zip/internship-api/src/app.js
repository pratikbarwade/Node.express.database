const express = require("express");
const cors = require("cors");
const morgan = require("morgan");

const internshipRoutes = require("./routes/internshipRoutes");
const { notFound, errorHandler } = require("./middleware/errorHandler");

const app = express();

app.use(cors());
app.use(express.json());
app.use(morgan(process.env.NODE_ENV === "test" ? "silent" : "dev"));

// Root route with a short human-friendly welcome + pointers.
app.get("/", (req, res) => {
  res.status(200).json({
    success: true,
    message: "Internship Records API is running.",
    docs: "See README.md for full API documentation.",
    endpoints: {
      health: "GET /api/health",
      list: "GET /api/v1/internships",
      detail: "GET /api/v1/internships/:id",
      create: "POST /api/v1/internships",
      replace: "PUT /api/v1/internships/:id",
      update: "PATCH /api/v1/internships/:id",
      remove: "DELETE /api/v1/internships/:id",
    },
  });
});

app.get("/api/health", (req, res) => {
  res.status(200).json({ success: true, status: "ok", uptime: process.uptime() });
});

app.use("/api/v1/internships", internshipRoutes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
