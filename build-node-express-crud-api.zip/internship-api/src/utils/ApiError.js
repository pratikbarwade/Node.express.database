// A small helper error class so controllers can throw errors with a
// specific HTTP status code and optional validation details.
class ApiError extends Error {
  constructor(statusCode, message, details = undefined) {
    super(message);
    this.statusCode = statusCode;
    this.details = details;
  }
}

module.exports = ApiError;
