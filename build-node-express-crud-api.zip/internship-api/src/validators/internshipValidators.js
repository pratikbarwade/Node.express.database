const { body, param, query } = require("express-validator");

const ALLOWED_TYPES = ["Remote", "Onsite", "Hybrid"];

const idParamValidator = [
  param("id").isInt({ min: 1 }).withMessage("id must be a positive integer"),
];

const listQueryValidator = [
  query("page").optional().isInt({ min: 1 }).withMessage("page must be a positive integer"),
  query("limit").optional().isInt({ min: 1, max: 50 }).withMessage("limit must be between 1 and 50"),
  query("type").optional().isIn(ALLOWED_TYPES).withMessage(`type must be one of: ${ALLOWED_TYPES.join(", ")}`),
  query("isOpen").optional().isIn(["true", "false", "0", "1"]).withMessage("isOpen must be true or false"),
  query("sortBy")
    .optional()
    .isIn(["id", "title", "company", "stipend", "duration_months", "posted_date", "application_deadline", "created_at"])
    .withMessage("Invalid sortBy field"),
  query("order").optional().isIn(["asc", "desc", "ASC", "DESC"]).withMessage("order must be asc or desc"),
];

// Used for POST (create) and PUT (full replace) — every field is required.
const createValidator = [
  body("title").trim().notEmpty().withMessage("title is required").isLength({ min: 3, max: 150 }),
  body("company").trim().notEmpty().withMessage("company is required").isLength({ min: 2, max: 120 }),
  body("location").trim().notEmpty().withMessage("location is required").isLength({ min: 2, max: 120 }),
  body("category").trim().notEmpty().withMessage("category is required").isLength({ min: 2, max: 80 }),
  body("type")
    .trim()
    .notEmpty()
    .withMessage("type is required")
    .isIn(ALLOWED_TYPES)
    .withMessage(`type must be one of: ${ALLOWED_TYPES.join(", ")}`),
  body("duration_months")
    .notEmpty()
    .withMessage("duration_months is required")
    .isInt({ min: 1, max: 24 })
    .withMessage("duration_months must be an integer between 1 and 24"),
  body("stipend")
    .notEmpty()
    .withMessage("stipend is required")
    .isInt({ min: 0 })
    .withMessage("stipend must be a non-negative integer"),
  body("is_open")
    .optional()
    .isBoolean()
    .withMessage("is_open must be a boolean"),
  body("description").optional({ nullable: true }).isString().isLength({ max: 2000 }),
  body("application_deadline")
    .optional({ nullable: true })
    .isISO8601()
    .withMessage("application_deadline must be a valid date (YYYY-MM-DD)"),
];

// Used for PATCH (partial update) — every field is optional but at least one must be present.
const patchValidator = [
  body("title").optional().trim().isLength({ min: 3, max: 150 }),
  body("company").optional().trim().isLength({ min: 2, max: 120 }),
  body("location").optional().trim().isLength({ min: 2, max: 120 }),
  body("category").optional().trim().isLength({ min: 2, max: 80 }),
  body("type").optional().trim().isIn(ALLOWED_TYPES).withMessage(`type must be one of: ${ALLOWED_TYPES.join(", ")}`),
  body("duration_months").optional().isInt({ min: 1, max: 24 }),
  body("stipend").optional().isInt({ min: 0 }),
  body("is_open").optional().isBoolean(),
  body("description").optional({ nullable: true }).isString().isLength({ max: 2000 }),
  body("application_deadline").optional({ nullable: true }).isISO8601(),
];

module.exports = {
  idParamValidator,
  listQueryValidator,
  createValidator,
  patchValidator,
  ALLOWED_TYPES,
};
