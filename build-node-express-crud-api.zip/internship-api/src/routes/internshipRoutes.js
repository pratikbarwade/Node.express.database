const express = require("express");
const controller = require("../controllers/internshipController");
const validateRequest = require("../middleware/validateRequest");
const {
  idParamValidator,
  listQueryValidator,
  createValidator,
  patchValidator,
} = require("../validators/internshipValidators");

const router = express.Router();

router
  .route("/")
  .get(listQueryValidator, validateRequest, controller.getInternships)
  .post(createValidator, validateRequest, controller.createInternship);

router
  .route("/:id")
  .get(idParamValidator, validateRequest, controller.getInternshipById)
  .put(idParamValidator, createValidator, validateRequest, controller.updateInternship)
  .patch(idParamValidator, patchValidator, validateRequest, controller.patchInternship)
  .delete(idParamValidator, validateRequest, controller.deleteInternship);

module.exports = router;
