require("dotenv").config();
const path = require("path");
const db = require("../config/db");
const seedData = require("./seed-data.json");

const isFresh = process.argv.includes("--fresh");

function seed() {
  const countRow = db.prepare("SELECT COUNT(*) AS count FROM internships").get();

  if (countRow.count > 0 && !isFresh) {
    console.log(
      `⚠️  The internships table already has ${countRow.count} row(s).\n` +
        "   Run 'npm run seed:fresh' to wipe and reseed, or delete the .db file first."
    );
    return;
  }

  const insert = db.prepare(`
    INSERT INTO internships
      (title, company, location, category, type, duration_months, stipend, is_open, description, application_deadline, posted_date)
    VALUES
      (@title, @company, @location, @category, @type, @duration_months, @stipend, @is_open, @description, @application_deadline, @posted_date)
  `);

  const insertMany = db.transaction((rows) => {
    if (isFresh) {
      db.prepare("DELETE FROM internships").run();
      db.prepare("DELETE FROM sqlite_sequence WHERE name = 'internships'").run();
    }
    for (const row of rows) {
      insert.run(row);
    }
  });

  insertMany(seedData);

  const finalCount = db.prepare("SELECT COUNT(*) AS count FROM internships").get().count;
  console.log(`✅ Seeded ${finalCount} internship record(s) into ${path.resolve(process.env.DB_PATH || "./data/internship.db")}`);
}

seed();
