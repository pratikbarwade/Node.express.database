-- Internship Records API - SQLite schema
-- Fictional data only. Safe to drop/recreate in development.

CREATE TABLE IF NOT EXISTS internships (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  title                 TEXT    NOT NULL,
  company               TEXT    NOT NULL,
  location              TEXT    NOT NULL,
  category              TEXT    NOT NULL,
  type                  TEXT    NOT NULL CHECK (type IN ('Remote', 'Onsite', 'Hybrid')),
  duration_months       INTEGER NOT NULL CHECK (duration_months BETWEEN 1 AND 24),
  stipend               INTEGER NOT NULL DEFAULT 0 CHECK (stipend >= 0),
  is_open               INTEGER NOT NULL DEFAULT 1 CHECK (is_open IN (0, 1)),
  description           TEXT,
  application_deadline  TEXT,
  posted_date           TEXT    NOT NULL DEFAULT (date('now')),
  created_at            TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at            TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_internships_category ON internships (category);
CREATE INDEX IF NOT EXISTS idx_internships_type     ON internships (type);
CREATE INDEX IF NOT EXISTS idx_internships_is_open   ON internships (is_open);
CREATE INDEX IF NOT EXISTS idx_internships_location  ON internships (location);
