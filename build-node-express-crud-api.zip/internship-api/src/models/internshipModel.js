const db = require("../config/db");

const ALLOWED_SORT_FIELDS = new Set([
  "id",
  "title",
  "company",
  "stipend",
  "duration_months",
  "posted_date",
  "application_deadline",
  "created_at",
]);

function toBooleanInt(value) {
  if (value === undefined) return undefined;
  return value === "true" || value === "1" || value === 1 || value === true ? 1 : 0;
}

/**
 * Finds internships with optional filters, sorting, and pagination.
 */
function findAll({ limit, offset, category, type, location, isOpen, search, sortBy, order }) {
  const where = [];
  const params = {};

  if (category) {
    where.push("category = @category COLLATE NOCASE");
    params.category = category;
  }
  if (type) {
    where.push("type = @type COLLATE NOCASE");
    params.type = type;
  }
  if (location) {
    where.push("location LIKE @location COLLATE NOCASE");
    params.location = `%${location}%`;
  }
  if (isOpen !== undefined) {
    where.push("is_open = @isOpen");
    params.isOpen = toBooleanInt(isOpen);
  }
  if (search) {
    where.push("(title LIKE @search COLLATE NOCASE OR company LIKE @search COLLATE NOCASE)");
    params.search = `%${search}%`;
  }

  const whereClause = where.length ? `WHERE ${where.join(" AND ")}` : "";

  const safeSortBy = ALLOWED_SORT_FIELDS.has(sortBy) ? sortBy : "id";
  const safeOrder = order && order.toLowerCase() === "desc" ? "DESC" : "ASC";

  const totalItems = db
    .prepare(`SELECT COUNT(*) AS count FROM internships ${whereClause}`)
    .get(params).count;

  const rows = db
    .prepare(
      `SELECT * FROM internships ${whereClause} ORDER BY ${safeSortBy} ${safeOrder} LIMIT @limit OFFSET @offset`
    )
    .all({ ...params, limit, offset });

  return { rows, totalItems };
}

function findById(id) {
  return db.prepare("SELECT * FROM internships WHERE id = ?").get(id);
}

function create(data) {
  const stmt = db.prepare(`
    INSERT INTO internships
      (title, company, location, category, type, duration_months, stipend, is_open, description, application_deadline, posted_date)
    VALUES
      (@title, @company, @location, @category, @type, @duration_months, @stipend, @is_open, @description, @application_deadline, COALESCE(@posted_date, date('now')))
  `);

  const info = stmt.run({
    ...data,
    is_open: data.is_open ?? 1,
    description: data.description ?? null,
    application_deadline: data.application_deadline ?? null,
    posted_date: data.posted_date ?? null,
  });

  return findById(info.lastInsertRowid);
}

function replace(id, data) {
  const stmt = db.prepare(`
    UPDATE internships SET
      title = @title,
      company = @company,
      location = @location,
      category = @category,
      type = @type,
      duration_months = @duration_months,
      stipend = @stipend,
      is_open = @is_open,
      description = @description,
      application_deadline = @application_deadline,
      updated_at = datetime('now')
    WHERE id = @id
  `);

  stmt.run({
    id,
    ...data,
    description: data.description ?? null,
    application_deadline: data.application_deadline ?? null,
  });

  return findById(id);
}

function patch(id, data) {
  const existing = findById(id);
  if (!existing) return undefined;

  const merged = { ...existing, ...data };

  const stmt = db.prepare(`
    UPDATE internships SET
      title = @title,
      company = @company,
      location = @location,
      category = @category,
      type = @type,
      duration_months = @duration_months,
      stipend = @stipend,
      is_open = @is_open,
      description = @description,
      application_deadline = @application_deadline,
      updated_at = datetime('now')
    WHERE id = @id
  `);

  stmt.run({
    id,
    title: merged.title,
    company: merged.company,
    location: merged.location,
    category: merged.category,
    type: merged.type,
    duration_months: merged.duration_months,
    stipend: merged.stipend,
    is_open: merged.is_open,
    description: merged.description ?? null,
    application_deadline: merged.application_deadline ?? null,
  });

  return findById(id);
}

function remove(id) {
  const existing = findById(id);
  if (!existing) return undefined;
  db.prepare("DELETE FROM internships WHERE id = ?").run(id);
  return existing;
}

module.exports = { findAll, findById, create, replace, patch, remove, ALLOWED_SORT_FIELDS };
