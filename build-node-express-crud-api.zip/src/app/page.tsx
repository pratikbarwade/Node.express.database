import { db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await db.execute(sql`select 1`);

  return (
    <main className="grid min-h-screen place-items-center px-6 py-12">
      <section className="w-full max-w-2xl rounded-3xl bg-white p-10 shadow-[0_24px_60px_rgba(16,24,40,0.12)]">
        <p className="m-0 text-sm uppercase tracking-[0.08em] text-slate-600">Submission notice</p>
        <h1 className="mt-4 text-[clamp(1.75rem,5vw,2.75rem)] font-semibold leading-[1.1] text-slate-950">
          Internship Records API lives in <code className="rounded bg-slate-100 px-2 py-1">/internship-api</code>
        </h1>
        <p className="mt-4 text-base text-slate-700">
          The graded deliverable for this task is a standalone{" "}
          <strong>Node.js + Express + SQLite</strong> REST API (with CRUD endpoints,
          validation, pagination, seed data, tests, and full API docs). It is not
          this Next.js page &mdash; find it in the <code>internship-api/</code>{" "}
          folder of this repository.
        </p>
        <ol className="mt-6 list-decimal space-y-1 pl-5 text-sm text-slate-700">
          <li>
            Read <code>internship-api/README.md</code> for setup instructions.
          </li>
          <li>
            Run <code>cd internship-api && npm install && npm run seed && npm run dev</code>.
          </li>
          <li>
            Explore <code>internship-api/docs/API_EXAMPLES.md</code> for curl examples.
          </li>
        </ol>
        <p className="mt-6 text-xs text-slate-500">
          (This page is only a placeholder from the Next.js/PostgreSQL sandbox
          template used to author the submission; it confirms the sandbox
          database connection is healthy.)
        </p>
      </section>
    </main>
  );
}
