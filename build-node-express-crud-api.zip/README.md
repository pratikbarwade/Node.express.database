# Internship Records API — Submission

This repository contains the complete deliverable for the assignment:

> **Create a Node.js and Express API for internship records with
> validation, pagination, and SQLite persistence.**

## 📁 Where to look

**👉 The full project lives in [`internship-api/`](./internship-api).**

That folder is a self-contained, GitHub-ready Node.js + Express + SQLite
project with everything required for submission:

- CRUD REST API for internship records (`create`, `list`, `detail`, `update`, `delete`)
- Input validation with clear, consistent error responses
- Pagination, filtering, and sorting on the list endpoint
- Auto-bootstrapped SQLite schema (`src/db/schema.sql`)
- Idempotent seed script + 15 fictional internship records
  (`src/db/seed-data.json`, `docs/seed-records.json`, `docs/sample-database.sql`)
- Automated smoke tests (`npm test`)
- Full API documentation with curl examples and a Postman collection
  (`docs/API_EXAMPLES.md`, `docs/postman_collection.json`)
- A detailed [`internship-api/README.md`](./internship-api/README.md) with
  setup instructions, schema docs, and the complete API reference

### Quick start

```bash
cd internship-api
npm install
cp .env.example .env
npm run seed
npm run dev
# API now running at http://localhost:4000
```

See [`internship-api/README.md`](./internship-api/README.md) for full
documentation (setup, schema, validation rules, pagination/filtering
parameters, and API examples).

---

## About the rest of this repository

The files outside of `internship-api/` (`src/app`, `drizzle.config.json`,
etc.) are an unrelated Next.js + PostgreSQL starter template provided by the
sandbox environment used to author this submission. They are **not** part of
the graded deliverable — the Node.js/Express/SQLite Internship Records API in
[`internship-api/`](./internship-api) is the complete, working submission.
